package Principal;

import Vista.InterfazGrafica_Mapa;

public class Main_Mapa {
	
	public static void main(String[] args) {
		
		InterfazGrafica_Mapa interfacGrafica = new InterfazGrafica_Mapa();
		
		interfacGrafica.setVisible(true);
		
	}
	
	
}