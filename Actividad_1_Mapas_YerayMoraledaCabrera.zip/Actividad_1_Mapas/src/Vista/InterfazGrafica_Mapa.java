package Vista;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.jtattoo.plaf.mint.MintLookAndFeel;

import Controlador.Logica_Mapa;

public class InterfazGrafica_Mapa extends JFrame {

    private static final long serialVersionUID = 1L;
    private static JPanel contentPane;
    private static String[] arrayBotones = {"Añadir Nota", "Eliminar", "Actualizar", "Ver notas"};
    public static JButton botones[];
    private Logica_Mapa ejecutarAcciones;
    public static DefaultTableModel modeloTabla;
    public static JTable tabla;
    private static JScrollPane scrollPane;
    

    public static void configurarTabla() {
        modeloTabla = new DefaultTableModel();
        tabla = new JTable(modeloTabla);

        scrollPane = new JScrollPane(tabla);
        contentPane.add(scrollPane);
    }

    public static void configurarBotones() {
        botones = new JButton[arrayBotones.length];
        for (int i = 0; i < arrayBotones.length; i++) {
            botones[i] = new JButton(arrayBotones[i]);
            botones[i].setFont(botones[i].getFont().deriveFont(14.0f));

            contentPane.add(botones[i]);
        }
    }

    private void ejecutar() {
        ejecutarAcciones = new Logica_Mapa(this);
        ejecutarAcciones.escucharEventos();
    }

    public InterfazGrafica_Mapa() {
    	setTitle("Mapa Estudiantes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        try {
            //Se establece el Look and Feel de JTattoo (MintLookAndFeel en este caso)
            UIManager.setLookAndFeel(new MintLookAndFeel());
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        
        configurarBotones();
        configurarTabla();
        ubicarComponentes();
        ejecutar();
    }

    private void ubicarComponentes() {
        int buttonWidth = 135;
        int buttonHeight = 30;
        int margin = 10;

        for (int i = 0; i < arrayBotones.length; i++) {
            botones[i].setSize(buttonWidth, buttonHeight);
            botones[i].setLocation(margin + i * (buttonWidth + margin), 10);
        }

        int tableWidth = 460;
        int tableHeight = 300;
        scrollPane.setBounds((getWidth() - tableWidth) / 2, 50, tableWidth, tableHeight);
    }

    public static void main(String[] args) {
        InterfazGrafica_Mapa frame = new InterfazGrafica_Mapa();
        frame.setResizable(false);
        frame.setVisible(true);
    }
}