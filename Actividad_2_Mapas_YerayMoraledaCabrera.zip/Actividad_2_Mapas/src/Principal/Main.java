package Principal;

import Vista.Vista;

public class Main {
	
	public static void main(String[] args) {
		
		//Instanciamos nuestra interfaz gráfica
		Vista vista = new Vista();
		
		vista.setVisible(true);
	}
	
	
}