package Vista;

public class Vista_4 {

    public void mostrarResultado(double precioMedio) {
        System.out.println("El precio medio de los productos es: " + precioMedio);
    }
}