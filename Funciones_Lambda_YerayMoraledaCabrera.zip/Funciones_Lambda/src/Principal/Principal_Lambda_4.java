package Principal;

import Controlador.Controlador_4;

public class Principal_Lambda_4 {

    public static void main(String[] args) {
        Controlador_4 controlador = new Controlador_4();
        controlador.calcularPrecioMedio();
    }
}