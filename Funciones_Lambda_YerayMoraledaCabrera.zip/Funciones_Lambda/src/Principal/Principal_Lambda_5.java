package Principal;

import Vista.Vista_5;

public class Principal_Lambda_5 {

	public static void main(String[] args) {

		//Instanciamos la interfaz gráfica de esta actividad
		Vista_5 vista = new Vista_5();
		
		vista.setVisible(true);


	}


}