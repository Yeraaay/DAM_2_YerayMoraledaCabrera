package Principal;

import Vista.Vista_1;

public class Principal_Lambda_1 {
	
	public static void main(String[] args) {
		
	//Instanciamos la interfaz gráfica
	Vista_1 vista = new Vista_1();
	
	vista.setVisible(true);
	
	}	
}