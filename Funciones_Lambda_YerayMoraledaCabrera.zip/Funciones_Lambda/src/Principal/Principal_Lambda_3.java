package Principal;

import Vista.Vista_3;

public class Principal_Lambda_3 {

	public static void main(String[] args) {

		//Instanciamos la interfaz gráfica de la actividad
		Vista_3 vista = new Vista_3();

		vista.setVisible(true);


	}


}