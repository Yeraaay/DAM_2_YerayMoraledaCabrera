package Principal;

import Vista.Vista_2;

public class Principal_Lambda_2 {
	
	public static void main(String[] args) {
		
		//Instanciamos la interfaz gráfica
		Vista_2 vista = new Vista_2();
		
		vista.setVisible(true);
		
	}	
	
}